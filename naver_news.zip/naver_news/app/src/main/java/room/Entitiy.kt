package room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "news")
data class NewsEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0, //DB 구분용
    val title: String,
    val originallink: String,
    val link: String,
    val description: String,
    val pubDate: String
)



