package room

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface NewsDao{
    // 뉴스 저장 (같은 PK면 덮어쓰기)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNews(news: NewsEntity)

    // 여러 개 한 번에 저장
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(newsList: List<NewsEntity>)

    // 전체 뉴스 가져오기 (최신순 정렬 예시)
    @Query("SELECT * FROM news ORDER BY pubDate DESC")
    suspend fun getAllNews(): List<NewsEntity>

    // 특정 뉴스 삭제
    @Delete
    suspend fun deleteNews(news: NewsEntity)

    // 전체 삭제
    @Query("DELETE FROM news")
    suspend fun deleteAll()

}