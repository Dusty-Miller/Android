package news

import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface NaverNewsApi {
    @Headers(
        "X-Naver-Client-Id: ff1FDMV_KytGQEHXntal",
        "X-Naver-Client-Secret: k3Jxk1Of5l "
    )
    @GET("v1/search/news.json")
    suspend fun searchNews(
        @Query("query") query: String,
        @Query("display") display: Int = 10,
        @Query("start") start: Int = 1,
        @Query("sort") sort: String = "sim"
    ): NaverNewsDTO
}