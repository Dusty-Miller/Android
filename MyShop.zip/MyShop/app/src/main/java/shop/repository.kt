package room

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import shop.Mall
import shop.NaverShopApi
import shop.Product
import shop.toProductEntity

class RoomRepository(
    private val productDao: ProductDao,
    private val userDao: UserDao,
    private val wishlistDao: WishlistDao
) {

    // Product 관련
    suspend fun insertProduct(product: ProductEntity) {
        productDao.insertProduct(product)
    }

    fun getBookmarks(userId: Int): Flow<List<ProductEntity>> {
        return productDao.getBookmarks(userId)
    }

    suspend fun deleteProduct(product: ProductEntity) {
        productDao.deleteProduct(product)
    }

    // User 관련
    suspend fun insertUser(user: UserEntity) {
        userDao.insertUser(user)
    }

    suspend fun getUserByUsername(username: String) : UserEntity? {
        return userDao.getUserByUsername(username)
    }

    suspend fun getUserByEmail(email: String) : UserEntity? {
        return userDao.getUserByEmail(email)
    }

    suspend fun login(username: String, password: String): UserEntity? {
        return userDao.login(username, password)
    }

    suspend fun addToWishlist(userId: Int, product: Product) {
        val entity = WishlistEntity(
            productLink = product.link,
            productTitle = product.title,
            productImage = product.image,
            productPrice = product.lprice.toIntOrNull() ?: 0,
            productMallName = product.mallName,
            userId = userId
        )
        wishlistDao.addToWishlist(entity)
    }

    suspend fun removeFromWishlist(userId: Int, productLink: String) {
        wishlistDao.removeByUserAndLink(userId, productLink)
    }

    fun getWishlist(userId: Int): Flow<List<ProductEntity>> {
        return wishlistDao.getWishlistByUser(userId)
            .map { wishlistEntities ->
                wishlistEntities.map { it.toProductEntity() } // 변환 함수 필요
            }
    }

    suspend fun isInWishlist(userId: Int, productLink: String): Boolean {
        return wishlistDao.isInWishlist(userId, productLink)
    }

    suspend fun deleteWishlistItem(wishlistEntity: WishlistEntity) {
        wishlistDao.delete(wishlistEntity)
    }

}

class RetrofitRepository(private val retrofitApi: NaverShopApi) {
    suspend fun naverFetchShop(query: String): Mall {
        return retrofitApi.searchMall(query)
    }
}
