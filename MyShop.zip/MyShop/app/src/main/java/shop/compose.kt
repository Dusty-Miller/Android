package shop

import ShopViewModel
import UserViewModel
import UserViewModelFactory
import WishlistViewModel
import WishlistViewModelFactory
import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.text.input.PasswordVisualTransformation
import coil.compose.AsyncImage
import room.ProductEntity
import room.RoomRepository
import room.WishlistEntity


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(viewModel: ShopViewModel, navController: NavController, userId: Int) {
    val shopList by viewModel.shopList.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        viewModel.naverFetchShop("헤드폰", userId) // 초기 검색어
    }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(8.dp)) {
        TopAppBar(
            title = { Text("Dusty Shop") },
            actions = {
                IconButton(onClick = { navController.navigate("list") }) {
                    Icon(Icons.Default.Home, contentDescription = "홈")
                }
                IconButton(onClick = { navController.navigate("wishlist") }) {
                    Icon(Icons.Default.Favorite, contentDescription = "위시리스트")
                }
                IconButton(onClick = { navController.navigate("settings") }) {
                    Icon(Icons.Default.Settings, contentDescription = "설정")
                }
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.weight(1f),
                label = { Text("상품 검색") },
                singleLine = true
            )
            Button(
                onClick = {
                    viewModel.naverFetchShop(searchQuery, userId)  // userId 넘기기
                },
                modifier = Modifier.alignByBaseline()
            ) {
                Text("검색")
            }
        }

        Spacer(Modifier.height(8.dp))

        LazyColumn(
            contentPadding = PaddingValues(),
            modifier = Modifier.fillMaxSize()
        ) {
            items(shopList) { product ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val encodedUrl = URLEncoder.encode(product.link, StandardCharsets.UTF_8.toString())
                            navController.navigate("webview/$encodedUrl")
                        },
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {
                    Column(Modifier.padding(8.dp)) {
                        AsyncImage(
                            model = product.image,  // 이미지 URL
                            contentDescription = product.title,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(product.title, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("최저가: ${product.lprice}원", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("판매처: ${product.mallName}", style = MaterialTheme.typography.labelSmall)

                        Spacer(Modifier.height(8.dp))

                        Button(onClick = {
                            viewModel.addToWishlist(userId, product)
                        }) {
                            Text("위시리스트 담기")
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ShopWebView(url: String) {
    AndroidView(factory = { context ->
        WebView(context).apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            loadUrl(url)
        }
    })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NaverShopAppNav(
    factory: ShopViewModel.ShopViewModelFactory,
    userId: Int,
    roomRepository: RoomRepository
) {
    val navController = rememberNavController()
    val shopViewModel: ShopViewModel = viewModel(factory = factory)
    val userViewModel: UserViewModel = viewModel(factory = UserViewModelFactory(roomRepository))
    val wishlistViewModelFactory = WishlistViewModelFactory(roomRepository)
    val wishlistViewModel: WishlistViewModel = viewModel(factory = wishlistViewModelFactory)

    val userLoggedIn by userViewModel.loginResult.collectAsState()

    NavHost(
        navController = navController,
        startDestination = if (userLoggedIn != null) "list" else "login"
    ) {
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate("list") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate("register")
                },
                roomRepository = roomRepository  // 꼭 추가!
            )
        }
        composable("register") {
            RegisterScreen(
                onRegisterSuccess = {
                    navController.navigate("login") {
                        popUpTo("register") { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() },
                roomRepository = roomRepository  // 꼭 넘겨줘야 합니다
            )
        }
        composable("list") {
            ShopScreen(viewModel = shopViewModel, navController = navController, userId = userId)
        }
        composable("webview/{url}") { backStackEntry ->
            val url = backStackEntry.arguments?.getString("url")?.let {
                java.net.URLDecoder.decode(it, StandardCharsets.UTF_8.toString())
            }
            url?.let { ShopWebView(it) }
        }
        composable("wishlist") {
            WishlistScreen(viewModel = wishlistViewModel, navController = navController, userId = userId)
        }
    }
}

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    onNavigateToRegister: () -> Unit,
    roomRepository: RoomRepository
) {
    val userViewModel: UserViewModel = viewModel(factory = UserViewModelFactory(roomRepository))

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val loginResult by userViewModel.loginResult.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("로그인", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("아이디") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("비밀번호") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                userViewModel.login(username, password)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("로그인")
        }

        Spacer(modifier = Modifier.height(8.dp))

        loginResult?.let { user ->
            if (user != null) {
                Text("로그인 성공!", color = MaterialTheme.colorScheme.primary)
                LaunchedEffect(user) {
                    onLoginSuccess()
                }
            } else {
                Text("아이디 또는 비밀번호가 올바르지 않습니다.", color = MaterialTheme.colorScheme.error)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(
            onClick = { onNavigateToRegister() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("회원가입 하러가기")
        }
    }
}


@Composable
fun RegisterScreen(
    onRegisterSuccess: () -> Unit,
    onBack: () -> Unit,
    roomRepository: RoomRepository
) {
    val userViewModel: UserViewModel = viewModel(factory = UserViewModelFactory(roomRepository))

    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordConfirm by remember { mutableStateOf("") }
    val signUpResult by userViewModel.signUpResult.collectAsState(initial = null)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("회원가입", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("아이디") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("이메일") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("비밀번호") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = passwordConfirm,
            onValueChange = { passwordConfirm = it },
            label = { Text("비밀번호 확인") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (password != passwordConfirm) {
                    // 비밀번호 불일치 메시지 표시
                    // 여기서는 간단히 return 처리만 함
                    return@Button
                }
                userViewModel.signUp(username, email, password)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("회원가입")
        }

        Spacer(modifier = Modifier.height(8.dp))

        signUpResult?.let { result ->
            if (result.isSuccess) {
                Text("회원가입 성공!", color = MaterialTheme.colorScheme.primary)
                LaunchedEffect(Unit) {
                    onRegisterSuccess()
                }
            } else {
                Text("회원가입 실패: ${result.exceptionOrNull()?.message}", color = MaterialTheme.colorScheme.error)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("뒤로가기")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WishlistScreen(
    viewModel: WishlistViewModel,
    navController: NavController,
    userId: Int
) {
    val wishlist by viewModel.getWishlist(userId).collectAsState(initial = emptyList<ProductEntity>())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("위시리스트") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "뒤로가기"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        if (wishlist.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Text(text = "위시리스트가 비어있습니다.")
            }
        } else {
            LazyColumn(
                contentPadding = paddingValues,
                modifier = Modifier.fillMaxSize()
            ) {
                items(wishlist) { product ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .clickable {
                                // 상품 상세 웹뷰로 이동
                                navController.navigate("webview/${java.net.URLEncoder.encode(product.link, "UTF-8")}")
                            },
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Row(Modifier.padding(8.dp)) {
                            AsyncImage(
                                model = product.image,
                                contentDescription = product.title,
                                modifier = Modifier.size(100.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(product.title, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(4.dp))
                                Text("최저가: ${product.lprice}원", style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.height(4.dp))
                                Text("판매처: ${product.mallName}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WebViewScreen(url: String) {
    AndroidView(factory = { context ->
        WebView(context).apply {
            settings.javaScriptEnabled = true
            loadUrl(url)
        }
    })
}



