package shop

import room.ProductEntity
import room.WishlistEntity

fun Product.toProductEntity(userId: Int): ProductEntity {
    return ProductEntity(
        link = this.link,
        title = this.title,
        image = this.image,
        lprice = this.lprice.toIntOrNull() ?: 0,  // lprice가 String이면 Int로 변환, 실패 시 0
        mallName = this.mallName,
        userId = userId
    )
}

fun WishlistEntity.toProductEntity(): ProductEntity {
    return ProductEntity(
        link = this.productLink,
        title = this.productTitle,
        image = this.productImage,
        lprice = this.productPrice,
        mallName = this.productMallName,
        userId = this.userId
    )
}
