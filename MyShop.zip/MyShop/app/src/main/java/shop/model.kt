package shop


data class Mall(
    val items: List<Product>
)

data class Product(
    val title: String,
    val link: String,
    val image: String,
    val lprice: String,
    val mallName: String
)