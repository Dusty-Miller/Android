import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import room.ProductEntity
import room.RetrofitRepository
import room.RoomRepository
import room.UserEntity
import room.WishlistEntity
import shop.Product
import shop.toProductEntity


class ShopViewModel(
    private val retrofitRepository: RetrofitRepository,
    private val roomRepository: RoomRepository
) : ViewModel() {

    fun addToWishlist(userId: Int, product: Product) {
        viewModelScope.launch {
            val wishlistItem = WishlistEntity(
                productLink = product.link,
                productTitle = product.title,
                productImage = product.image,
                productPrice = product.lprice.toIntOrNull() ?: 0,
                productMallName = product.mallName,
                userId = userId
            )
            roomRepository.addToWishlist(userId, product)
        }
    }



    fun removeFromWishlist(userId: Int, productLink: String) {
        viewModelScope.launch {
            roomRepository.removeFromWishlist(userId, productLink)
        }
    }

    fun checkWishlist(userId: Int, productLink: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val isIn = roomRepository.isInWishlist(userId, productLink)
            onResult(isIn)
        }
    }

    // 네이버 API 호출
    private val _shopList = MutableStateFlow<List<Product>>(emptyList())
    val shopList: StateFlow<List<Product>> = _shopList

    fun naverFetchShop(query: String, userId: Int) {
        viewModelScope.launch {
            try {
                val response = retrofitRepository.naverFetchShop(query)
                _shopList.value = response.items

                // 네이버 API의 Product를 Room의 ProductEntity로 변환 후 DB 저장
                response.items.forEach { product ->
                    val entity = product.toProductEntity(userId)  // userId 전달
                    roomRepository.insertProduct(entity)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


    class ShopViewModelFactory(
        private val retrofitRepository: RetrofitRepository,
        private val roomRepository: RoomRepository
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ShopViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return ShopViewModel(retrofitRepository, roomRepository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

class UserViewModel(private val roomRepository: RoomRepository) : ViewModel() {

    private val _loginResult = MutableStateFlow<UserEntity?>(null)
    val loginResult: StateFlow<UserEntity?> = _loginResult

    private val _signUpResult = MutableStateFlow<Result<Unit>?>(null)
    val signUpResult: StateFlow<Result<Unit>?> = _signUpResult

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val user = roomRepository.login(username, password)
            if (user != null) {
                _loginResult.value = user
                _signUpResult.value = null
            } else {
                _loginResult.value = null
                _signUpResult.value = Result.failure(Exception("아이디 또는 비밀번호가 올바르지 않습니다."))
            }
        }
    }

    fun signUp(username: String, email: String, password: String) {
        viewModelScope.launch {
            val existingUser = roomRepository.getUserByUsername(username)
            if (existingUser != null) {
                _signUpResult.value = Result.failure(Exception("이미 존재하는 사용자 이름입니다."))
                return@launch
            }
            val newUser = UserEntity(username = username, email = email, password = password)
            roomRepository.insertUser(newUser)
            _signUpResult.value = Result.success(Unit)
        }
    }
}

class UserViewModelFactory(private val roomRepository: RoomRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UserViewModel(roomRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class WishlistViewModel(private val roomRepository: RoomRepository) : ViewModel() {

    private val _wishlist = MutableStateFlow<List<ProductEntity>>(emptyList())
    val wishlist: StateFlow<List<ProductEntity>> = _wishlist

//    fun loadWishlist(userId: Int) {
//        viewModelScope.launch {
//            roomRepository.getWishlist(userId).collect { list ->
//                _wishlist.value = list
//            }
//        }
//    }

    fun removeFromWishlist(wishlistEntity: WishlistEntity) {
        viewModelScope.launch {
            roomRepository.deleteWishlistItem(wishlistEntity)
        }
    }

    fun getWishlist(userId: Int): Flow<List<ProductEntity>> {
        return roomRepository.getWishlist(userId) // 혹은 변환 포함된 코드
    }
}

class WishlistViewModelFactory(
    private val repository: RoomRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WishlistViewModel::class.java)) {
            return WishlistViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
