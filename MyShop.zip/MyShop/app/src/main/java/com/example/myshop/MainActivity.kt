package com.example.naver_news

import ShopViewModel
import UserViewModelFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.room.Room
import com.example.myshop.ui.theme.MyShopTheme
import room.AppDatabase
import room.RoomRepository
import room.ProductDao
import room.UserDao
import shop.NaverShopAppNav
import shop.RetrofitClient


class MainActivity : ComponentActivity() {

    private lateinit var roomRepository: RoomRepository
    val currentUserId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Room Database 생성
        val db = AppDatabase.getInstance(applicationContext)

        val productDao = db.productDao()
        val userDao = db.userDao()

        roomRepository = RoomRepository(productDao, userDao, wishlistDao = db.wishlistDao() )

        val retrofitRepository = RetrofitClient.retrofitRepository

        val shopViewModelFactory =
            ShopViewModel.ShopViewModelFactory(retrofitRepository, roomRepository)
        val userViewModelFactory = UserViewModelFactory(roomRepository)


        setContent {
            MyShopTheme {
                NaverShopAppNav(factory = shopViewModelFactory, userId = currentUserId, roomRepository = roomRepository)
            }
        }
    }
}

