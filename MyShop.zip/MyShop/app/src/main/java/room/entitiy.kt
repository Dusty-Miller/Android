package room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val link: String,
    val title: String,
    val image: String,
    val lprice: Int,
    val mallName: String,
    val userId: Int
)

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val password: String,
    val email: String // 정상 / 해지
)

@Entity(tableName = "wishlist")
data class WishlistEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productLink: String,
    val productTitle: String,
    val productImage: String,
    val productPrice: Int,
    val productMallName: String,
    val userId: Int
)

