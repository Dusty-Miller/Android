package room

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Query("SELECT * FROM products WHERE userId = :userId")
    fun getBookmarks(userId: Int): Flow<List<ProductEntity>>

    @Delete
    suspend fun deleteProduct(product: ProductEntity)
}

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    suspend fun login(username: String, password: String): UserEntity?

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?
}

@Dao
interface WishlistDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addToWishlist(wishlistItem: WishlistEntity)

    @Delete
    suspend fun removeFromWishlist(wishlistItem: WishlistEntity)

    @Query("SELECT * FROM wishlist WHERE userId = :userId")
    fun getWishlistByUser(userId: Int): Flow<List<WishlistEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM wishlist WHERE userId = :userId AND productLink = :productLink)")
    suspend fun isInWishlist(userId: Int, productLink: String): Boolean

    @Delete
    suspend fun delete(wishlistEntity: WishlistEntity)

    @Query("DELETE FROM wishlist WHERE userId = :userId AND productLink = :productLink")
    suspend fun removeByUserAndLink(userId: Int, productLink: String)

}

